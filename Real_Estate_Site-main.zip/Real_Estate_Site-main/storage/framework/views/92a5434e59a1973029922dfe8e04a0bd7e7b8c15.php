<?php $__env->startSection('content_box'); ?>
    <div class="container text-center" style="height: 30em">
        <div class="container-fluid m-auto">
            <div class="mt-5">
                <h1>404 Not Found<h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Real_Estate_Site-main\resources\views/errors/404.blade.php ENDPATH**/ ?>