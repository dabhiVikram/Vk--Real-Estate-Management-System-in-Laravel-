{{-- @push('title')
    Home
@endpush --}}
@include('layouts.header')
@include('layouts.navbar')

@yield('content_box')

@include('layouts.footer')
@include('layouts.close')
