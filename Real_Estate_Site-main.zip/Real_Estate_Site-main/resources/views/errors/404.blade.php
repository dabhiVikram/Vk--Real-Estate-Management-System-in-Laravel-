@extends('layouts.app')
@section('content_box')
    <div class="container text-center" style="height: 30em">
        <div class="container-fluid m-auto">
            <div class="mt-5">
                <h1>404 Not Found<h1>
            </div>
        </div>
    </div>
@endsection
